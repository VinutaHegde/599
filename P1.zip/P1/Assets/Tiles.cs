﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tiles : MonoBehaviour
{
    public int val;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void updateScore()
    {
        if (TileManager.turn == 1)
            ScoreManager.scoreValA += val;
        else
            ScoreManager.scoreValB += val;
        TileManager.turn *= -1;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
