﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    public Text[] scoreTexts;
    public static int scoreValA = 0, scoreValB = 0;

    // Start is called before the first frame update
    void Start()
    {
        scoreTexts[0].text = "Score: " + scoreValA;
        scoreTexts[1].text = "Score: " + scoreValB;
    }

    // Update is called once per frame
    void Update()
    {
        scoreTexts[0].text = "Score: " + scoreValA;
        scoreTexts[1].text = "Score: " + scoreValB;
    }
}
