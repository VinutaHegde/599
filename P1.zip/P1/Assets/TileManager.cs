﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TileManager : MonoBehaviour
{

    public Button[] btnList;
    public static int turn = 1;

    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < btnList.Length; i++)
        {
            btnList[i].GetComponentInChildren<Text>().text = "" + (i + 1);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (turn == 1)
        {
            for (int i = 4; i < btnList.Length; i++)
                btnList[i].interactable = false;
            for (int i = 0; i < 4; i++)
                btnList[i].interactable = true;
        }
        else
        {
            for (int i = 0; i < 4; i++)
                btnList[i].interactable = false;
            for (int i = 4; i < btnList.Length; i++)
                btnList[i].interactable = true;
        }
    }
}
